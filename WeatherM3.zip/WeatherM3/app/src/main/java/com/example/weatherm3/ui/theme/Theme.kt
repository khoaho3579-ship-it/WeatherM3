package com.example.weatherm3.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFF405D92), onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E2FF), onPrimaryContainer = Color(0xFF001A42),
    secondary = Color(0xFF575E71), tertiary = Color(0xFF715573),
    surface = Color(0xFFF9F9FF), background = Color(0xFFF9F9FF)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFFADC6FF), onPrimary = Color(0xFF092F60),
    primaryContainer = Color(0xFF284777), onPrimaryContainer = Color(0xFFD8E2FF),
    secondary = Color(0xFFBEC6DC), tertiary = Color(0xFFDEBCE0),
    surface = Color(0xFF111318), background = Color(0xFF111318)
)

@Composable
fun WeatherTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = isSystemInDarkTheme()
    val colors = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        shapes = Shapes(
            extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(4.dp),
            small = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
            large = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
