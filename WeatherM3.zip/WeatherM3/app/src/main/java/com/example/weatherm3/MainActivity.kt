package com.example.weatherm3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent\nimport androidx.compose.animation.togetherWith
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.weatherm3.data.OpenMeteoRepository
import com.example.weatherm3.data.WeatherSnapshot
import com.example.weatherm3.ui.theme.WeatherTheme
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WeatherTheme { WeatherApp() } }
    }
}

class WeatherViewModel : ViewModel() {
    private val repository = OpenMeteoRepository()
    var weather by mutableStateOf<WeatherSnapshot?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var city by mutableStateOf("Đang tải vị trí mẫu…"); private set

    init { refresh() }
    fun refresh() {
        viewModelScope.launch {
            loading = true; error = null
            runCatching { repository.load(10.7769, 106.7009) }
                .onSuccess { weather = it; city = "Thành phố Hồ Chí Minh" }
                .onFailure { error = it.message ?: "Không thể tải dữ liệu" }
            loading = false
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherApp(vm: WeatherViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var fahrenheit by remember { mutableStateOf(false) }
    val tabs = listOf("Hôm nay", "Theo giờ", "Địa điểm", "Cài đặt")
    Scaffold(
        bottomBar = {
            NavigationBar {
                val icons = listOf(Icons.Rounded.WbSunny, Icons.Rounded.Schedule, Icons.Rounded.Place, Icons.Rounded.Settings)
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = label) }, label = { Text(label) })
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = vm::refresh, icon = { Icon(Icons.Rounded.Refresh, null) }, text = { Text("Làm mới") })
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(vm, fahrenheit, { fahrenheit = it }, Modifier.padding(padding))
            1 -> HourlyScreen(vm, Modifier.padding(padding))
            2 -> LocationsScreen(city = vm.city, modifier = Modifier.padding(padding))
            else -> SettingsScreen(fahrenheit, { fahrenheit = it }, Modifier.padding(padding))
        }
    }
}

@Composable
fun HomeScreen(vm: WeatherViewModel, fahrenheit: Boolean, setF: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val w = vm.weather
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.city, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Cập nhật ${LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = vm::refresh) { Icon(Icons.Rounded.Search, "Tìm địa điểm") }
        }
        Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hiện tại", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        AnimatedContent(targetState = w?.temperatureC, transitionSpec = { androidx.compose.animation.fadeIn(spring()) togetherWith androidx.compose.animation.fadeOut(spring()) }, label = "temperature") { temp ->
                            Text(temp?.let { "${if (fahrenheit) (it * 9 / 5 + 32).toInt() else it.toInt()}°" } ?: "--°",
                                style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Light)
                        }
                        Text(w?.description ?: if (vm.loading) "Đang lấy dữ liệu…" else "Chưa có dữ liệu", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Icon(Icons.Rounded.WbSunny, null, Modifier.size(92.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Text("Cảm giác như ${w?.feelsLikeC?.toInt() ?: "--"}°  •  Cao ${w?.maxC?.toInt() ?: "--"}° / Thấp ${w?.minC?.toInt() ?: "--"}°",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !fahrenheit, onClick = { setF(false) }, label = { Text("°C") })
                    FilterChip(selected = fahrenheit, onClick = { setF(true) }, label = { Text("°F") })
                }
            }
        }
        if (vm.error != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text("Không thể cập nhật: ${vm.error}. Đang hiển thị dữ liệu khả dụng.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
        Text("Dự báo 24 giờ", style = MaterialTheme.typography.titleLarge)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(w?.hourly ?: emptyList()) { hour ->
                ElevatedCard(shape = MaterialTheme.shapes.large) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(hour.time, style = MaterialTheme.typography.labelMedium)
                        Icon(Icons.Rounded.Cloud, null, Modifier.padding(vertical = 8.dp))
                        Text("${hour.temperature.toInt()}°", style = MaterialTheme.typography.titleMedium)
                        Text("${hour.rain.toInt()}% mưa", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        Text("Thông tin thời tiết", style = MaterialTheme.typography.titleLarge)
        val metrics = listOf(
            "Độ ẩm" to (w?.humidity?.let { "$it%" } ?: "--"),
            "Gió" to (w?.windKmh?.let { "${it.toInt()} km/h" } ?: "--"),
            "UV" to (w?.uv?.toString() ?: "--"),
            "Áp suất" to (w?.pressure?.let { "$it hPa" } ?: "--"),
            "Tầm nhìn" to (w?.visibility?.let { "${it / 1000} km" } ?: "--"),
            "Mưa" to (w?.rainProbability?.let { "$it%" } ?: "--")
        )
        metrics.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (label, value) ->
                    ElevatedCard(Modifier.weight(1f), shape = MaterialTheme.shapes.large) {
                        Column(Modifier.padding(16.dp)) {
                            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
                            Text(value, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            }
        }
        Text("Nguồn dữ liệu: Open-Meteo", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun HourlyScreen(vm: WeatherViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Dự báo theo giờ", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        vm.weather?.hourly?.forEach { Text("${it.time}     ${it.temperature.toInt()}°     Mưa ${it.rain.toInt()}%") }
            ?: Text("Đang tải dữ liệu thời tiết…")
    }
}
@Composable
fun LocationsScreen(city: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Địa điểm", style = MaterialTheme.typography.headlineMedium)
        ElevatedCard { ListItem(headlineContent = { Text(city) }, supportingContent = { Text("Vị trí mặc định mẫu") }, leadingContent = { Icon(Icons.Rounded.LocationOn, null) }) }
        Text("Bản dựng khởi đầu đang dùng tọa độ TP. Hồ Chí Minh; có thể mở rộng tìm kiếm geocoding trong phiên bản tiếp theo.", style = MaterialTheme.typography.bodyMedium)
    }
}
@Composable
fun SettingsScreen(fahrenheit: Boolean, setF: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Cài đặt", style = MaterialTheme.typography.headlineMedium)
        ElevatedCard(shape = MaterialTheme.shapes.extraLarge) {
            ListItem(headlineContent = { Text("Đơn vị nhiệt độ") }, supportingContent = { Text("Chọn cách hiển thị nhiệt độ") },
                trailingContent = { Row { FilterChip(!fahrenheit, { setF(false) }, label = { Text("°C") }); Spacer(Modifier.width(6.dp)); FilterChip(fahrenheit, { setF(true) }, label = { Text("°F") }) } })
            HorizontalDivider()
            ListItem(headlineContent = { Text("Nguồn dữ liệu") }, supportingContent = { Text("Open-Meteo · miễn phí, không cần API key") })
            HorizontalDivider()
            ListItem(headlineContent = { Text("Giao diện") }, supportingContent = { Text("Dynamic color trên Android 12+; theo hệ thống") })
            HorizontalDivider()
            ListItem(headlineContent = { Text("Giới thiệu") }, supportingContent = { Text("Weather M3 1.0.0 · Dữ liệu Open-Meteo") })
        }
    }
}
