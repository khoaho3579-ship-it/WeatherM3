package com.example.weatherm3.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

data class HourForecast(val time: String, val temperature: Double, val rain: Double)
data class WeatherSnapshot(
    val temperatureC: Double, val feelsLikeC: Double, val maxC: Double, val minC: Double,
    val description: String, val humidity: Int, val windKmh: Double, val uv: Double,
    val pressure: Int, val visibility: Int, val rainProbability: Int, val hourly: List<HourForecast>
)

class OpenMeteoRepository {
    suspend fun load(latitude: Double, longitude: Double): WeatherSnapshot = withContext(Dispatchers.IO) {
        val endpoint = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,visibility" +
            "&hourly=temperature_2m,precipitation_probability,uv_index&daily=temperature_2m_max,temperature_2m_min,uv_index_max" +
            "&forecast_days=10&timezone=auto"
        val json = JSONObject(URL(endpoint).readText())
        val current = json.getJSONObject("current")
        val daily = json.getJSONObject("daily")
        val hourly = json.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temps = hourly.getJSONArray("temperature_2m")
        val rain = hourly.getJSONArray("precipitation_probability")
        val hours = (0 until minOf(24, times.length())).map { i ->
            HourForecast(times.getString(i).takeLast(5), temps.getDouble(i), rain.getDouble(i))
        }
        val code = current.optInt("weather_code", 0)
        WeatherSnapshot(
            current.getDouble("temperature_2m"),
            current.getDouble("apparent_temperature"),
            daily.getJSONArray("temperature_2m_max").getDouble(0),
            daily.getJSONArray("temperature_2m_min").getDouble(0),
            weatherDescription(code),
            current.optInt("relative_humidity_2m"),
            current.optDouble("wind_speed_10m"),
            hourly.getJSONArray("uv_index").optDouble(0),
            current.optDouble("pressure_msl").toInt(),
            current.optDouble("visibility").toInt(),
            rain.optInt(0),
            hours
        )
    }
    private fun weatherDescription(code: Int) = when (code) {
        0 -> "Trời quang đãng"
        1, 2 -> "Ít mây"
        3 -> "Nhiều mây"
        45, 48 -> "Sương mù"
        in 51..67 -> "Mưa phùn / mưa"
        in 71..77 -> "Tuyết"
        in 80..82 -> "Mưa rào"
        in 95..99 -> "Dông"
        else -> "Thời tiết thay đổi"
    }
}
