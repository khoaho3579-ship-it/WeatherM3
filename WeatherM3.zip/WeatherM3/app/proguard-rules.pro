# Keep serialization models if minification is enabled.
