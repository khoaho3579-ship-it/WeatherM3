# Weather M3

Ứng dụng Android thời tiết mẫu dùng Kotlin, Jetpack Compose và Material 3, lấy dữ liệu thật từ Open-Meteo.

## Build APK bằng GitHub Actions
1. Giải nén `WeatherM3.zip`.
2. Tạo repository GitHub mới và đưa toàn bộ nội dung thư mục `WeatherM3` lên nhánh `main`.
3. Mở tab **Actions**; workflow **Build Android APK** tự chạy sau khi push.
4. Mở lần chạy thành công, tải artifact **WeatherM3-debug-apk**.
5. Giải nén artifact và cài APK. Nếu Android hỏi, cho phép cài ứng dụng từ nguồn bạn vừa dùng để tải.

Có thể chạy thủ công từ máy đã cài JDK 17, Android SDK và Gradle 8.13:
`gradle assembleDebug`

## Dữ liệu và quyền riêng tư
- Dữ liệu thời tiết: Open-Meteo Forecast API. Ứng dụng hiện dùng tọa độ mẫu TP. Hồ Chí Minh.
- Ứng dụng cần Internet. Bản khởi đầu chưa yêu cầu quyền GPS; không gửi dữ liệu vị trí cá nhân.
- Open-Meteo: https://open-meteo.com/ (xem điều khoản ghi công/giấy phép hiện hành trước khi phát hành).
- AndroidX / Jetpack Compose: Apache License 2.0; Retrofit, OkHttp, Kotlinx Serialization và các thư viện khác theo giấy phép của từng dự án.

## Phạm vi bản 1.0.0
Đã có: project Gradle, workflow APK, Compose UI responsive theo chiều rộng khả dụng, Dynamic Color, sáng/tối theo hệ thống, dữ liệu current + hourly + daily từ Open-Meteo, chuyển °C/°F và màn hình cơ bản.

Chưa triển khai trong bản này: Room cache offline, DataStore, Hilt, WorkManager, geocoding/search, AQI, radar, widget Glance, Google Weather API, toàn bộ tùy biến Expressive nâng cao và dịch đầy đủ. Không nhập Google API key vào bản hiện tại. Các mục này cần triển khai và kiểm thử riêng trước khi coi đây là ứng dụng hoàn chỉnh.
